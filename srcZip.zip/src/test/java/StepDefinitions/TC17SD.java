package Hotels;

import Class1.DateLib;
import Class1.MyDriver;
import LocatorsMethods.LandingPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.testng.Assert;

public class TC17SD {

    LandingPage lpage = new LandingPage();

    @Given("I am on hotels landing page")
    public void OpenHotels() {
        MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");
    }

    @And("I click on Check-in Calendar")
    public void clickCheckInBox() {
        lpage.clickIt(By.id("d1-btn"));
    }

    @Then("I go to current month and verify past dates are disabled")
    public void pastDaysDisabled() {
        Assert.assertEquals(DateLib.getCurrentDateAsInt() - 1, lpage.disabledDays(), "Test failed");

        @Then("I verify Back button on current month is disabled")
        public void backButtonDisabled () {
            Assert.assertTrue(lpage.isBackArrowDisabled());
        }
        @And("I click on Check-out Calendar")
        public void clickCheckOut () {
            lpage.clickCheckOutBox();
        }
        @Then("I verify past dates if any are disabled in Check-out")
        public void pastDisabledDays () {
            Assert.assertEquals(DateLib.getCurrentDateAsInt() - 1, lpage.pastDisabledDays(), "Test failed");
        }
    }
}
