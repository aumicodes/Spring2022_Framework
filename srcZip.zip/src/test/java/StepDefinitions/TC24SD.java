package Hotels;

import Class1.MyDriver;
import LocatorsMethods.LandingPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.testng.Assert;

public class TC24SD extends LandingPage {

    LandingPage lPage = new LandingPage();

    @Given("I am on hotels landing page")
    public void OpenHotels() {
        MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");
    }

    @And("I Select “Website feedback” from Help dropdown")
    public void WebsiteFeedback() {
        lPage.findWebElement(By.xpath("//nav//button[text()='Sign in']")).click();
        lPage.findWebElement(By.xpath("//div[@class='header-guest-heading']/following-sibling::div//a/div[text()='Feedback']")).click();
    }

    @And("I Click on Submit button")
    public void ClickSubmit() {
        lPage.findWebElement(By.xpath("//*[@id='submit-button']")).click();
    }

    @Then("I verify error message is displayed")
    public void VerifyErrorMessageDisplayed() {
        Assert.assertTrue(lPage.verificationMessageLocator());
    }

    @Then("I verify star boxes section is in a red dotted box.")
    public boolean VerifyDottedStarBox() {
        Assert.assertTrue(lPage.isRedBoxDisplayed());
    }
}
