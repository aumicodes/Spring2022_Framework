package StepDefinitions;

import Class1.Commands;
import Class1.MyDriver;
import LocatorsMethods.LandingPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.runtime.io.Helpers;
import org.openqa.selenium.By;
import org.testng.Assert;

public class TC21SD extends Commands {

    LandingPage lpage = new LandingPage();

    @Given("I am on hotels landing page")
    public void OpenHotels()
    {MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");}

    @And("I click on Sign-in Link")
    public void SignIn() {
        lpage.findWebElement(By.xpath("//nav//button[text()='Sign in']")).click();
        lpage.findWebElement(By.xpath("//div[@class='actions']//a[@data-stid='link-header-account-signin']")).click();
    }

    @And("I enter invalid email address")
    public void EnterInvalidEmail() {
        lpage.findWebElement(By.xpath("//*[@id='loginFormEmailInput']")).sendKeys("zxcvbnhfvs@gmail.com");
    }

    @And("I enter invalid password")
    public void EnterInvalidPassword() {
        lpage.findWebElement(By.xpath("//*[@id='loginFormPasswordInput']")).sendKeys("hmmmm");
    }

    @And("I click on Sign-in button")
    public void ClickSignIn(){
        lpage.findWebElement(By.xpath("//*[@id='loginFormSubmitButton']")).click();
    }

    @Then("I verify that the verification message is displayed")
    public void VerificationMessage(){
       lpage.findWebElement(By.xpath("//h3[text()='Email and password don't match. Try again.']")).getText();
        String VerifyVerificationMessage = MyDriver.getDriver().findElement(By.xpath("//h1[text()='Terms and Conditions']")).getText();
        Assert.assertEquals(VerifyVerificationMessage,"Email and password don't match. Try again.");
    }

}