package Class1;

import Class1.Misc;
import Class1.MyDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class PracticeTests {

    @org.testng.annotations.Test

    public void OpenHotels() {
        MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");
        MyDriver.getDriver().findElement(By.xpath("//nav//button[text()='Sign in']")).click();
        MyDriver.getDriver().findElement(By.xpath("//div[@class='header-guest-heading']/following-sibling::div//a/div[text()='Feedback']")).click();
    }

    @org.testng.annotations.Test
    public void OpenNewWindow() {
        MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");
        Misc.pause(2);
        MyDriver.quitWindows();
    }
}