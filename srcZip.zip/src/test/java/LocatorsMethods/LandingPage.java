package LocatorsMethods;

import Class1.Commands;
import Class1.MyDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class LandingPage extends Commands {

    //
    By checkInDateBoxLocator = By.id("d1-btn");
    By checkInDisabledDatesLocator = By.xpath("//table[@class='uitk-date-picker-weeks']//button[@disabled]");


    By june2022DatesLocator = By.xpath("//h2[text()='June 2022']/following-sibling::table//button[@data-day]");
    /*

        monthYear = August 2022
        "//h2[text()='" + monthYear + "']/following-sibling::table//button[@data-day]"
        monthDates_1 + monthYear + monthDates_2
     */
    String monthDates_1 = "//h2[text()='";
    String monthDates_2 = "']/following-sibling::table//button[@data-day]";

    By calendarHeading = By.xpath("(//div[@data-stid='date-picker-month'])[1]//h2");
    By nextMonthArrow = By.xpath("(//button[@data-stid='date-picker-paging'])[2]");


    By destinationInputBoxLocator = By.xpath("//button[@aria-label='Going to']");
    By destinationInputLocator = By.id("location-field-destination");
    By destinationSuggestions = By.xpath("//div[@class='uitk-typeahead-results']//div[contains(@class,'truncat') and not(contains(@class,'uitk'))]");


    public void clickCheckInBox() {
        clickIt(checkInDateBoxLocator);
    }

    public List<WebElement> getAllDisabledDates() {
        return findWebElements(checkInDisabledDatesLocator);
    }

    public void selectDateInJune2022(String dateToSelect) {
        selectDateInCalendar(june2022DatesLocator, dateToSelect);
    }

    public void enterDestination(String destination) {
        clickIt(destinationInputBoxLocator);
        type(destinationInputLocator, destination);
    }

    public void selectFromDestinationSuggestion(String userChoice) {
        selectFromSuggestions(destinationSuggestions, userChoice);
    }

    public void goToMonth(String monthYear) {
        for (int i = 0; i < 12; i++) {
            if (getTextOfWebElement(calendarHeading).equalsIgnoreCase(monthYear)) {
                break;
            }
            clickIt(nextMonthArrow);
        }
    }

    public void selectDateFromAnyMonth(String monthYear, String dateValue) {
        goToMonth(monthYear);
        By allDatesLocator = By.xpath(monthDates_1 + monthYear + monthDates_2);
        selectDateInCalendar(allDatesLocator, dateValue);
    }


    public void selectDateFromAnyMonth(String dateMonthYear) {
        String[] dateValues = dateMonthYear.split(" ");
        goToMonth(dateValues[1] + " " + dateValues[2]);
        By allDatesLocator = By.xpath(monthDates_1 + dateValues[1] + " " + dateValues[2] + monthDates_2);
        selectDateInCalendar(allDatesLocator, dateValues[0]);
    }

    public void autoSuggestion() {
        // #1
        MyDriver.launchUrlOnNewWindow("https://www.hotels.com/");

        MyDriver.getDriver().findElement(By.xpath("//button[@aria-label='Going to']")).click();
        MyDriver.getDriver().findElement(By.id("location-field-destination")).sendKeys("new");

        List<WebElement> allSuggestions = MyDriver.getDriver().findElements(By.xpath("//div[@class='uitk-typeahead-results']//div[contains(@class,'truncat') and not(contains(@class,'uitk'))]"));

        for (WebElement suggestion : allSuggestions) {
            if (suggestion.getText().equalsIgnoreCase("NEWPORT")) {
                suggestion.click();
                break;
            }
        }
    }


    By travelersBoxLocator = By.xpath("//button[@data-testid='travelers-field-trigger' and @type='button']");
    By increaseAdultsLocator = By.xpath("(//span[@class='uitk-step-input-button'])[2]");
    By increaseChildrenLocator = By.xpath("(//span[@class='uitk-step-input-button'])[4]");

    By primarySignInButtonLocator = By.xpath("//nav//button[text()='Sign in']");
    By secondarySignInButtonLocator = By.xpath("//div[@class='actions']//a[@data-stid='link-header-account-signin']");
    By signUpButtonLocator = By.xpath("//div[@class='actions']//a[@data-stid='link-header-account-signup']");
    By inputEmailLocator = By.xpath("//*[@id='loginFormEmailInput']");
    By inputPasswordLocator = By.xpath("//*[@id='loginFormPasswordInput']");
    By finalSignInButtonLocator = By.xpath("//*[@id='loginFormSubmitButton']");
    By signInErrorMessageLocator = By.xpath("//*[@id='loginFormErrorBanner']");

    By monthLocator = By.xpath("//div[@class='uitk-date-picker date-picker-menu']//span[@class='uitk-date-picker-selection-date']");
    By anotherMonthLC = By.xpath("//div[@class='uitk-date-picker-month']");
    By whateverMonthLC = By.xpath("//h2[@class='uitk-date-picker-month-name uitk-type-medium']");
    By leftMonthArrow = By.xpath("(//button[@data-stid='date-picker-paging'])[1]");
    By checkOutDateBoxLocator = By.id("d2-btn");
    By doneCheckInAndOutButton = By.xpath("//button[@data-stid='apply-date-picker']");

    By privacyPageLinkLocator = By.xpath("//a[text()='Privacy Statement']");
    By privacyPageHeadingLocator = By.xpath("//h2[text()='Privacy Statement']");
    By termsConditionsPageLinkLocator = By.xpath("//a[text()='Terms and Conditions']");
    By termsConditionsHeadingLocator = By.xpath("//h1[text()='Terms and Conditions']");
    By verificationMessageLocator = By.xpath("//h3[text()='Email and password don't match. Try again.'']");

    By redDottedBorderLocator = By.xpath("//*[contains(@style,'2px dotted rgb')]");
    By blankFormSubmissionErrorLocator = By.xpath("//*[@id='required']");
    By feedbackLinkLocator = By.xpath("//div[@class='header-guest-heading']/following-sibling::div//a/div[text()='Feedback']");
    By submitBtnLocator = By.xpath("//*[@id='submit-button']");

    public boolean disabledDays() {
        List<WebElement> disabledDates = findWebElements(checkInDisabledDatesLocator);
        int disabledDaysInCalendar = disabledDates.size();
        return disabledDaysInCalendar;


        public void ClickTravelersBox () {
            clickIt(travelersBoxLocator);
        }

        public String getTextOfTravelerBox;
        () {
            return getTextOfWebElement(travelersBoxLocator);

            public void clickAddAdults () {
                clickIt(increaseAdultsLocator);

                public void clickAddChildren () {
                    clickIt(increaseChildrenLocator);
                }
            }
        }

        public boolean isBackArrowDisabled () {
            WebElement backArrow = findWebElement(leftMonthArrow);
            boolean arrowIsDisabled = !backArrow.isEnabled();
            return arrowIsDisabled;
        }
    }

    public void clickCheckOutBox() {
        clickIt(checkOutDateBoxLocator);
    }

    public int pastDisabledDays() {
        List<WebElement> disabledDates = findWebElements(checkInDisabledDatesLocator);
        int disabledDaysInCalendar = disabledDates.size();
        return disabledDaysInCalendar;

    }

    public boolean feedbackErrorIsDisplayed() {
        return isElementDisplayed(verificationMessageLocator);

        public boolean isRedBoxDisplayed() {
            return isElementDisplayed(redDottedBorderLocator);

        }
    }
}
